create definer = root@localhost trigger tg_ins_order
    after insert
    on `order`
    for each row
BEGIN
    INSERT INTO h_order VALUES(null, NEW.order_id, NEW.address_id, NEW.user_id, NEW.cart_id, NEW.delivery_id,
                               NEW.date, NEW.status, NEW.state,
                               NEW.tx_status, NEW.tx_id,NEW.tx_host, NEW.tx_user_id, NEW.tx_date);
END;

