create definer = root@localhost trigger tg_ins_user
    after insert
    on user
    for each row
BEGIN
    INSERT INTO h_user VALUES(null, NEW.user_id, NEW.address_id, NEW.firstname, NEW.lastname, NEW.phone,
                              NEW.email, NEW.password,
                              NEW.tx_status,NEW.tx_date, NEW.tx_id,NEW.tx_host, NEW.tx_user_id);
END;

